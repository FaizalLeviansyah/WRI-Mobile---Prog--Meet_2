package com.example.youtubeuiclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
